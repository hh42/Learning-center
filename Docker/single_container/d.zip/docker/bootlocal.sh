mkdir /var/www
mount -t vboxsf www /var/www