# Docker-compose

Voici ma configuration pour un environnemente de dev bas� sur Docker. Cette configuration est avant tout faites pour mes besoin mais je me suis dit que �a pourrait servir � d'autres.

Pour que cette configuration fonctionne il est imp�ratif que vos fichiers web soit � la racine de `/var/www`